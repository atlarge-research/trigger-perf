import time
import boto3
import json
import logging
import sys


def get_size(input_string):
    # Calculate the size of the input string in bytes
    string_bytes = input_string.encode('latin-1')  # Encode string to bytes
    size_in_bytes = len(string_bytes)
    return size_in_bytes


'''
Puts the key and data into s3 bucket
returns: xar_id, put_time
'''
def s3_put_object(file_key, data):
    s3_client = boto3.client('s3')
    s3_bucket = 'test-buck-ritul'
    metadata = {'e_id': str(0)} # Remove later
    put_time = time.time()
    resp = s3_client.put_object(
        Bucket=s3_bucket,
        Key=file_key,
        Body=json.dumps(data),
        Metadata=metadata,
        ContentType='application/json'
    )
    xar_id = resp['ResponseMetadata']['HTTPHeaders']['x-amz-request-id']
    return xar_id, put_time


def s3Express_put_object():
    pass

def dynamo_put_object():
    pass



# need to enable versioning to gaurantee a notification for every event
def lambda_handler(event, context):

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    recv_time = time.time()

    file_key = event[0]
    data_to_write = event[1]
    e_id = event[2]
    run_id = event[3]
    ds = event[4]
    ksize = get_size(file_key)
    print(f"KEY SIZE RECVED: {ksize}")
    vsize = get_size(data_to_write)

    # Putting object into required data store
    if ds == "s3":
        xar_id, put_time = s3_put_object(file_key,data_to_write)
    elif ds == "s3Express":
        pass
    elif ds == "dynamo":
        pass

    
    log_data = {
        'run_id': run_id,
        'xar_id': xar_id,
        'event': 'WRITE',
        'exec_start_time': recv_time,
        'put_time': put_time,
        'key': file_key,
        'key_size': ksize,
        'value_size': vsize
    }
    logger.info(json.dumps(log_data))

    return {
        'statusCode': 200,
        'body': 'Lambda executed successfully!',
    }

